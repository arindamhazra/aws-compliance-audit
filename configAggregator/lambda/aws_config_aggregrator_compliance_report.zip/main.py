import boto3,logging,json,os,csv
from botocore.config import Config
import botocore
from datetime import datetime
from time import gmtime,strftime

sns = boto3.client('sns')
config_client = boto3.client('config')

def get_compliance_report():
    try:
        snsMsg = ""
        response = config_client.describe_configuration_aggregators()
        for configAggregrator in response['ConfigurationAggregators']:
            configAggregratorName = configAggregrator['ConfigurationAggregatorName']
            response = config_client.describe_aggregate_compliance_by_config_rules(
                ConfigurationAggregatorName=configAggregratorName           
            )
            for configRule in response['AggregateComplianceByConfigRules']:
                response = config_client.get_aggregate_compliance_details_by_config_rule(
                    ConfigurationAggregatorName=configAggregratorName,
                    ConfigRuleName=configRule['ConfigRuleName'],
                    AccountId=configRule['AccountId'],
                    AwsRegion=configRule['AwsRegion'],
                    ComplianceType='NON_COMPLIANT'
                )
                if response:
                    count = 1
                    for configRuleResult in response['AggregateEvaluationResults']:
                        accountId = configRuleResult['AccountId']
                        awsRegion = configRuleResult['AwsRegion']
                        configRuleName = configRuleResult['EvaluationResultIdentifier']['EvaluationResultQualifier']['ConfigRuleName']
                        resourceType = configRuleResult['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceType']
                        resourceId = configRuleResult['EvaluationResultIdentifier']['EvaluationResultQualifier']['ResourceId']
                        complianceType = configRuleResult['ComplianceType']
                        print("%s,%s,%s,%s,%s,%s,%s" %(configAggregratorName,accountId,awsRegion,resourceType,resourceId,configRuleName,complianceType))
                        snsMsg += "%s) AggregratorName = %s, AccountName = %s,Region = %s,ResoureType = %s,ResourceId = %s,RuleName = %s,ComplianceType = %s\n" %(count,configAggregratorName,accountId,awsRegion,resourceType,resourceId,configRuleName,complianceType) 
                        count +=1
    except botocore.exceptions.ClientError as e:
        print(e)
    return snsMsg

def send_sns_message(snsArn,aName,msg):
    if msg == "":
        subData = "INFORMATION : All Resources are Compliant"
        msgData = "Config Aggregator found all resources Compliant as per defined Guard rails on all Aggregation Accounts.\n"
    else:
        subData = "WARNING : Non-Compliant Resource(s) found"
        msgData = "Config Aggregator found following Non-Compliant resource(s) as per defined Guard rails on Aggregation Account(s).\n"
        msgData = msgData + "\n" + msg
    
    sns.publish(
        TargetArn=snsArn,
        Subject=subData,
        Message=str(msgData)
    )

def lambda_handler(event,context):
    snsTopicArn = os.environ['snsTopicArn']
    accountName = context.invoked_function_arn.split(":")[4]
    snsMsg = get_compliance_report()
    send_sns_message(snsTopicArn,accountName,snsMsg)
    